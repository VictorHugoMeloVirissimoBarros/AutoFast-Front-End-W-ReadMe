Você deve ter node.js instalado em sua maquina.

Ao fazer download do arquivo .Zip e extrair, abra-o no VS code, e inicie um terminal no powershell.
No terminal do powershell, cole o codigo:
npm install

O codigo "npm install" irá criar uma pasta de modules do react que fará com que o código funcione.
Após criar os módulos, será necessário abrir o powershell novamente e colocar o codigo:
npm run dev

apartir disso, procure por uma mensagem como
"VITE v6.x.x  ready in 300 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: http://192.168.0.105:5173/"

e apartir disso, copie o endereço local como por exemplo: "http://localhost:5173/" e coloque
em seu navegador para exuctar em local host