import { Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Register from "./pages/Cadastro";
import Login from "./pages/Login";
import Budget from "./pages/Budget";
import { DefaultLayout } from "./DefaultLayout";
import Chat from "./pages/Chat";
import Profile from "./pages/Perfil";
import Dashboard from "./pages/Dashboard";
import { ProtectedRoute } from "./ProtectedRoute";

export function Router() {
  return (
    <div className="app">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/cadastrar" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route element={<ProtectedRoute />}>
          <Route element={<DefaultLayout />}>
            <Route path="/orcamentos" element={<Budget />} />
            <Route path="/chat" element={<Chat />} />
            <Route path="/perfil" element={<Profile />} />
            <Route path="/painel" element={<Dashboard />} />
          </Route>
        </Route>
      </Routes>
    </div>
  );
}
