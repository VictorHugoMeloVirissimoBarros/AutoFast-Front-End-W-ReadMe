import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import axios from 'axios';
import './styele.scss';
import { IoMdClose } from 'react-icons/io';
import {
  criarOrcamento, criarPeca, listarClientes, listarVeiculosPorCliente,
  criarVeiculo, criarClienteParaOrcamento,
} from '../../services/api';
import type { Cliente, Veiculo } from '../../services/api';

interface Props { toggleModal: () => void; onCreated: () => void }

export function ModalCreateBudget({ toggleModal, onCreated }: Props) {
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [clienteId, setClienteId] = useState('');
  const [veiculoId, setVeiculoId] = useState('');
  const [adicionandoCliente, setAdicionandoCliente] = useState(false);
  const [nomeCliente, setNomeCliente] = useState('');
  const [emailCliente, setEmailCliente] = useState('');
  const [telefoneCliente, setTelefoneCliente] = useState('');
  const [adicionandoVeiculo, setAdicionandoVeiculo] = useState(false);
  const [salvandoVeiculo, setSalvandoVeiculo] = useState(false);
  const [marca, setMarca] = useState('');
  const [modelo, setModelo] = useState('');
  const [ano, setAno] = useState('');
  const [descricaoProblema, setDescricaoProblema] = useState('');
  const [fotoUrl, setFotoUrl] = useState('');
  const [valorPecas, setValorPecas] = useState('');
  const [valorMaoDeObra, setValorMaoDeObra] = useState('');
  const [prazoEntrega, setPrazoEntrega] = useState('');
  const [erro, setErro] = useState('');
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    listarClientes()
      .then(({ data }) => setClientes(data))
      .catch(() => setErro('Não foi possível carregar os clientes. Verifique se o Back-end está ativo.'));
  }, []);

  async function handleSelecionarCliente(id: string) {
    setClienteId(id);
    setVeiculoId('');
    setVeiculos([]);
    setErro('');
    if (!id) return;
    try {
      const { data } = await listarVeiculosPorCliente(Number(id));
      setVeiculos(data);
    } catch {
      setErro('Não foi possível carregar os veículos deste cliente.');
    }
  }

  async function handleAdicionarCliente() {
    if (!nomeCliente.trim() || !emailCliente.trim()) {
      setErro('Informe o nome e o e-mail do cliente.');
      return;
    }
    try {
      const { data } = await criarClienteParaOrcamento({
        nome: nomeCliente.trim(),
        email: emailCliente.trim(),
        telefone: telefoneCliente.trim(),
      });
      setClientes((anteriores) => [...anteriores, data]);
      await handleSelecionarCliente(String(data.id));
      setAdicionandoCliente(false);
      setNomeCliente('');
      setEmailCliente('');
      setTelefoneCliente('');
      setErro('');
    } catch (error) {
      setErro(axiosErrorMessage(error, 'Não foi possível cadastrar o cliente. Verifique se o e-mail já está em uso.'));
    }
  }

  async function handleAdicionarVeiculo() {
    setErro('');
    if (!clienteId) {
      setErro('Selecione um cliente primeiro.');
      return;
    }
    if (!marca.trim() || !modelo.trim() || !ano || !Number.isInteger(Number(ano)) || Number(ano) < 1900 || Number(ano) > 2100) {
      setErro('Preencha marca, modelo e um ano válido (entre 1900 e 2100).');
      return;
    }

    setSalvandoVeiculo(true);
    try {
      const { data } = await criarVeiculo({
        marca: marca.trim(),
        modelo: modelo.trim(),
        ano: Number(ano),
        cliente: { id: Number(clienteId) },
      });
      setVeiculos((anteriores) => [...anteriores, data]);
      setVeiculoId(String(data.id));
      setAdicionandoVeiculo(false);
      setMarca('');
      setModelo('');
      setAno('');
      setErro('');
    } catch (error) {
      setErro(axiosErrorMessage(error, 'Falha ao salvar o veículo. Confira se o Back-end está ativo e tente novamente.'));
    } finally {
      setSalvandoVeiculo(false);
    }
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErro('');
    if (!clienteId || !veiculoId) {
      setErro('Selecione um cliente e um veículo antes de criar o orçamento.');
      return;
    }
    setSalvando(true);
    try {
      const peca = await criarPeca({ descricaoProblema, fotoUrl: fotoUrl.trim() || ' ' });
      await criarOrcamento({
        status: 'PENDENTE',
        cliente: { id: Number(clienteId) },
        veiculo: { id: Number(veiculoId) },
        peca: { id: peca.data.id },
        valorPecas: valorPecas ? Number(valorPecas) : null,
        valorMaoDeObra: valorMaoDeObra ? Number(valorMaoDeObra) : null,
        valorTotal: (Number(valorPecas) || 0) + (Number(valorMaoDeObra) || 0),
        prazoEntrega: prazoEntrega ? Number(prazoEntrega) : null,
      });
      onCreated();
      toggleModal();
    } catch (error) {
      setErro(axiosErrorMessage(error, 'Não foi possível salvar o orçamento. Confira os dados e tente novamente.'));
    } finally {
      setSalvando(false);
    }
  }

  return <div className="modal-create-budget">
    <div className="modal-create-budget-container">
      <div className="modal-creat-budget-header">
        <h3>Novo orçamento</h3>
        <button type="button" onClick={toggleModal} className="modal-creat-budget-btn" aria-label="Fechar"><IoMdClose size={18}/></button>
      </div>
      <div className="modal-create-budget-body">
        <form id="form-novo-orcamento" className="modal-create-budget-body-form" onSubmit={handleSubmit}>
          <h4>Dados do cliente e veículo</h4>
          {!adicionandoCliente ? <>
            <div className="form-fiel">
              <label htmlFor="clienteId">Cliente</label>
              <select id="clienteId" value={clienteId} onChange={e => handleSelecionarCliente(e.target.value)} required>
                <option value="">Selecione um cliente</option>
                {clientes.map(c => <option key={c.id} value={c.id}>{c.nome} — {c.email}</option>)}
              </select>
            </div>
            <button type="button" className="modal-inline-action" onClick={() => { setAdicionandoCliente(true); setErro(''); }}>+ Adicionar cliente</button>
          </> : <div className="inline-create-fields">
            <div className="form-fiel"><label htmlFor="nomeCliente">Nome do cliente</label><input id="nomeCliente" value={nomeCliente} onChange={e => setNomeCliente(e.target.value)} placeholder="Nome completo" /></div>
            <div className="form-fiel"><label htmlFor="emailCliente">E-mail do cliente</label><input id="emailCliente" type="email" value={emailCliente} onChange={e => setEmailCliente(e.target.value)} placeholder="cliente@email.com" /></div>
            <div className="form-fiel"><label htmlFor="telefoneCliente">Telefone (opcional)</label><input id="telefoneCliente" value={telefoneCliente} onChange={e => setTelefoneCliente(e.target.value)} placeholder="(11) 99999-9999" /></div>
            <div className="inline-actions"><button type="button" onClick={handleAdicionarCliente}>Salvar cliente</button><button type="button" onClick={() => setAdicionandoCliente(false)}>Cancelar</button></div>
          </div>}

          {!adicionandoCliente && <>
            {!adicionandoVeiculo ? <>
              <div className="form-fiel">
                <label htmlFor="veiculoId">Veículo</label>
                <select id="veiculoId" value={veiculoId} onChange={e => setVeiculoId(e.target.value)} required disabled={!clienteId}>
                  <option value="">Selecione um veículo</option>
                  {veiculos.map(v => <option key={v.id} value={v.id}>{v.marca} {v.modelo} — {v.ano}</option>)}
                </select>
              </div>
              <button type="button" className="modal-inline-action" disabled={!clienteId} onClick={() => { setAdicionandoVeiculo(true); setVeiculoId(''); setErro(''); }}>+ Adicionar veículo</button>
            </> : <div className="inline-create-fields">
              <div className="form-fiel"><label htmlFor="marca">Marca</label><input id="marca" value={marca} onChange={e => setMarca(e.target.value)} placeholder="Ex.: Fiat" /></div>
              <div className="form-fiel"><label htmlFor="modelo">Modelo</label><input id="modelo" value={modelo} onChange={e => setModelo(e.target.value)} placeholder="Ex.: Uno" /></div>
              <div className="form-fiel"><label htmlFor="ano">Ano</label><input id="ano" type="number" min="1900" max="2100" value={ano} onChange={e => setAno(e.target.value)} placeholder="Ex.: 2015" /></div>
              <div className="inline-actions">
                <button type="button" onClick={handleAdicionarVeiculo} disabled={salvandoVeiculo}>
                  {salvandoVeiculo ? 'Salvando veículo...' : 'Salvar veículo'}
                </button>
                <button type="button" onClick={() => { setAdicionandoVeiculo(false); setVeiculoId(''); setErro(''); }} disabled={salvandoVeiculo}>Cancelar</button>
              </div>
              {erro && <p role="alert" className="form-error">{erro}</p>}
            </div>}
            </>}

          <h4>Dados da peça / serviço</h4>
          <div className="form-fiel"><label htmlFor="descricaoProblema">Descrição do problema</label><textarea id="descricaoProblema" value={descricaoProblema} onChange={e => setDescricaoProblema(e.target.value)} placeholder="Descreva o problema relatado pelo cliente..." required rows={3}/></div>
          <div className="form-fiel"><label htmlFor="fotoUrl">URL da foto (opcional)</label><input id="fotoUrl" value={fotoUrl} onChange={e => setFotoUrl(e.target.value)} placeholder="https://..." /></div>
          <h4>Valores e prazo</h4>
          <div className="form-fiel"><label htmlFor="valorPecas">Valor das peças (R$)</label><input id="valorPecas" type="number" min="0" step="0.01" value={valorPecas} onChange={e => setValorPecas(e.target.value)} placeholder="Valor das peças" /></div>
          <div className="form-fiel"><label htmlFor="valorMaoDeObra">Valor da mão de obra (R$)</label><input id="valorMaoDeObra" type="number" min="0" step="0.01" value={valorMaoDeObra} onChange={e => setValorMaoDeObra(e.target.value)} placeholder="Valor da mão de obra" /></div>
          <div className="form-fiel"><label htmlFor="prazoEntrega">Prazo de entrega (dias)</label><input id="prazoEntrega" type="number" min="1" value={prazoEntrega} onChange={e => setPrazoEntrega(e.target.value)} placeholder="Prazo em dias" /></div>
          {erro && <p role="alert" className="form-error">{erro}</p>}
        </form>
      </div>
      <div className="modal-create-budget-footer">
        <div className="modal-creat-budget-footer-buttons">
          <button type="button" onClick={toggleModal} className="modal-creat-budget-btn-cancel">Cancelar</button>
          <button type="submit" form="form-novo-orcamento" disabled={salvando || adicionandoCliente || adicionandoVeiculo} className="modal-creat-budget-btn-submit">{salvando ? 'Salvando...' : 'Criar orçamento'}</button>
        </div>
      </div>
    </div>
  </div>;
}

function axiosErrorMessage(error: unknown, fallback: string) {
  if (axios.isAxiosError(error)) {
    const data = error.response?.data;
    if (typeof data === 'string' && data.trim()) return data;
    if (data && typeof data === 'object') {
      const body = data as { detail?: string; message?: string; error?: string };
      return body.detail || body.message || body.error || `${fallback} (HTTP ${error.response?.status ?? 'sem resposta'})`;
    }
    return `${fallback} (HTTP ${error.response?.status ?? 'sem resposta'})`;
  }
  return fallback;
}
