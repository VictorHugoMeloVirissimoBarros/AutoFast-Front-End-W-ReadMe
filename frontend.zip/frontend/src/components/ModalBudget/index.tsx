import { IoMdClose } from 'react-icons/io';
import { useState } from 'react';
import type { Orcamento } from '../../services/api';
import './style.scss';

interface Props { orcamento: Orcamento; onClose: () => void; onDelete: () => void; onStatusChange: (status: Orcamento['status']) => void; onUpdate: (dados: Partial<Orcamento>) => void }

export function ModalBudget({ orcamento, onClose, onDelete, onStatusChange, onUpdate }: Props) {
  const [valorPecas, setValorPecas] = useState(String(orcamento.valorPecas ?? ''));
  const [valorMaoDeObra, setValorMaoDeObra] = useState(String(orcamento.valorMaoDeObra ?? ''));
  const [prazoEntrega, setPrazoEntrega] = useState(String(orcamento.prazoEntrega ?? ''));
  const valor = orcamento.valorTotal?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) || 'A definir';
  const status = { PENDENTE: 'Pendente', EM_ANALISE: 'Em análise', APROVADO: 'Aprovado', RECUSADO: 'Recusado' }[orcamento.status];
  return <div className="modal-budget"><div className="modal-budget-container">
    <div className="modal-budget-header"><div className="modal-budget-header-content"><div className="modal-budget-header-title"><h3>Orçamento #{orcamento.id}</h3><span className="modal-budget-status">{status}</span></div><div className="modal-budget-header-buttons"><button type="button" onClick={onClose} className="modal-budget-btn-close" aria-label="Fechar orçamento"><IoMdClose size={17}/></button></div></div></div>
    <div className="modal-budget-body"><div className="modal-budget-body-info"><p><span>Cliente:</span> {orcamento.cliente?.nome || 'Não informado'}</p><p><span>Telefone:</span> {orcamento.cliente?.telefone || 'Não informado'}</p><p><span>Veículo:</span> {orcamento.veiculo ? `${orcamento.veiculo.marca} ${orcamento.veiculo.modelo} (${orcamento.veiculo.ano})` : 'Não informado'}</p><p><span>Data:</span> {orcamento.dataSolicitacao ? new Date(orcamento.dataSolicitacao).toLocaleString('pt-BR') : 'Não informada'}</p></div>
      <div className="modal-budget-body-client-request"><div className="cr-label">Descrição do problema</div><p>{orcamento.peca?.descricaoProblema || 'Nenhuma descrição cadastrada.'}</p></div>
      {orcamento.peca?.fotoUrl?.trim() && <div className="modal-budget-body-img"><img src={orcamento.peca.fotoUrl} alt="Foto da peça"/></div>}
      <div className="modal-budget-section"><h4>Valores e prazo</h4><p>Peças: {orcamento.valorPecas?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) || 'A definir'}</p><p>Mão de obra: {orcamento.valorMaoDeObra?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) || 'A definir'}</p><p><strong>Total: {valor}</strong></p><p>Prazo: {orcamento.prazoEntrega ? `${orcamento.prazoEntrega} dias` : 'A definir'}</p><div className="modal-budget-edit-fields"><label>Valor das peças (R$)<input type="number" min="0" step="0.01" value={valorPecas} onChange={e => setValorPecas(e.target.value)}/></label><label>Mão de obra (R$)<input type="number" min="0" step="0.01" value={valorMaoDeObra} onChange={e => setValorMaoDeObra(e.target.value)}/></label><label>Prazo (dias)<input type="number" min="1" value={prazoEntrega} onChange={e => setPrazoEntrega(e.target.value)}/></label><button type="button" className="modal-budget-btn-approve" onClick={() => onUpdate({ valorPecas: valorPecas ? Number(valorPecas) : undefined, valorMaoDeObra: valorMaoDeObra ? Number(valorMaoDeObra) : undefined, prazoEntrega: prazoEntrega ? Number(prazoEntrega) : undefined, valorTotal: (Number(valorPecas) || 0) + (Number(valorMaoDeObra) || 0) })}>Salvar alterações</button></div></div>
    </div>
    <div className="modal-budget-footer"><button type="button" className="modal-budget-btn-reject" onClick={onDelete}>Excluir orçamento</button>{orcamento.status !== 'APROVADO' && <button type="button" className="modal-budget-btn-approve" onClick={() => onStatusChange('APROVADO')}>Marcar como aprovado</button>}{orcamento.status !== 'EM_ANALISE' && <button type="button" className="modal-budget-btn-approve" onClick={() => onStatusChange('EM_ANALISE')}>Em análise</button>}</div>
  </div></div>;
}

export function BudgetDetails() { return null; }
