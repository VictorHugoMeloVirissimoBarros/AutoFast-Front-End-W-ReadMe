import { useEffect, useState } from 'react';
import { api } from '../../services/api';
import './style.scss';

interface Mensagem { id: number; conteudo: string; dataHoraEnvio?: string; remetente?: { id: number; nome?: string } }
interface Props { orcamentoId?: number }

export function Chat({ orcamentoId }: Props) {
  const [mensagens, setMensagens] = useState<Mensagem[]>([]);
  const [erro, setErro] = useState('');
  useEffect(() => {
    if (!orcamentoId) return;
    api.get<Mensagem[]>(`/mensagens/orcamento/${orcamentoId}`)
      .then(r => setMensagens(r.data))
      .catch(() => setErro('Não foi possível carregar as mensagens.'));
  }, [orcamentoId]);
  return <div className="chat"><div className="chat-container"><div className="chat-messages">
    {!orcamentoId ? <p>Selecione um orçamento para visualizar a conversa.</p> : erro ? <p role="alert">{erro}</p> : mensagens.length === 0 ? <p>Nenhuma mensagem registrada para este orçamento.</p> : mensagens.map(m => <div className="chat-message" key={m.id}><div className="chat-bubble"><p>{m.conteudo}</p><span className="chat-time">{m.dataHoraEnvio ? new Date(m.dataHoraEnvio).toLocaleString('pt-BR') : ''}</span></div></div>)}
  </div></div>{orcamentoId && <p className="chat-input-area">O envio de mensagens será habilitado após a integração da autenticação.</p>}</div>;
}
