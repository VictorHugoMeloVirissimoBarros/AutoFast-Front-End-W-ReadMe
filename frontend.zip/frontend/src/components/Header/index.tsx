import { Link, useLocation } from 'react-router-dom';
import './style.scss';
import { useState } from 'react';

export function Header() {
    const location = useLocation();
    const [activeLink, setActiveLink] = useState(location.pathname);
    const usuarioSalvo = localStorage.getItem('autofast_usuario');
    let nomeUsuario = 'Minha oficina';
    try {
        if (usuarioSalvo) nomeUsuario = JSON.parse(usuarioSalvo).nome || nomeUsuario;
    } catch { /* mantém o nome padrão */ }

    function handleLinkClick(link: string) {
        setActiveLink(link)
    }

    return (
        <header className="header" id="header">
            <div className='header-left'>
                <div className="header-profile">
                    <div className="header-avatar">OF</div>
                    <div className="header-profile-info">
                        <div className="header-profile-name">{nomeUsuario}</div>
                    </div>
                    <div className="header-badge-online"></div>
                </div>
                <Link to="/orcamentos"
                    className={`nav-item ${activeLink === '/orcamentos' ? 'active' : ''}`}
                    onClick={() => handleLinkClick('/orcamentos')}
                >
                    Orçamentos
                </Link>

                <Link to="/painel"
                    className={`nav-item ${activeLink === '/painel' ? 'active' : ''}`}
                    onClick={() => handleLinkClick('/painel')}
                >
                    Painel
                </Link>

            </div>

            <div className='header-right'>
                <Link to="/perfil" >
                    Perfil
                </Link>
            </div>


        </header>
    );
}