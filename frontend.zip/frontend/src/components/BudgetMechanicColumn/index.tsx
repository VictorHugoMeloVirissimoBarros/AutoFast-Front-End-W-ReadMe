import { CiClock2 } from 'react-icons/ci';
import { IoAddSharp } from 'react-icons/io5';

interface CardItem { id: string; title: string; client: string; value: string; time: string; initials: string; tone: 'blue' | 'orange' | 'green'; tag: string; onClick?: () => void }
interface BoardColumn { title: string; count: number; accent: 'blue' | 'purple' | 'yellow' | 'orange' | 'green' | 'gray'; cards: CardItem[] }
interface Props { column: BoardColumn; toggleModal: () => void; toggleModalBudget: () => void }

export function BudgetMechanicColumn({ column, toggleModal }: Props) {
  return <section className="dashboard-mechanic-column" role="listitem" data-accent={column.accent}>
    <div className="dashboard-mechanic-column-header"><div className="dashboard-mechanic-column-title-row"><span className="dashboard-mechanic-column-dot" aria-hidden="true"/><h2 className="dashboard-mechanic-column-title">{column.title}</h2><span className="dashboard-mechanic-column-count">{column.count}</span></div><button type="button" onClick={toggleModal} className="dashboard-mechanic-column-add" aria-label={`Adicionar orçamento em ${column.title}`}><IoAddSharp/></button></div>
    <div className="dashboard-mechanic-cards">{column.cards.length ? column.cards.map(card => <article key={card.id} onClick={card.onClick} onKeyDown={e => { if (e.key === 'Enter') card.onClick?.(); }} role="button" tabIndex={0} className="dashboard-mechanic-card"><div className="dashboard-mechanic-card-top"><span className="dashboard-mechanic-time"><CiClock2/> {card.time}</span></div><div className="dashboard-mechanic-code">{card.id}</div><h3 className="dashboard-mechanic-card-title">{card.client}</h3><p className="dashboard-mechanic-card-text">{card.title}</p><div className="dashboard-mechanic-card-footer"><div className="dashboard-mechanic-price">{card.value}</div></div></article>) : <p className="dashboard-mechanic-cards-alert">Nenhum orçamento nesta etapa</p>}</div>
    <button type="button" onClick={toggleModal} className="dashboard-mechanic-add-new"><IoAddSharp size={12}/> Novo orçamento</button>
  </section>;
}
