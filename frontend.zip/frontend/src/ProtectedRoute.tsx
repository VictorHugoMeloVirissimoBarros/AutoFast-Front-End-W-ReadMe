import { Navigate, Outlet } from 'react-router-dom';

export function ProtectedRoute() {
  return localStorage.getItem('autofast_token') ? <Outlet /> : <Navigate to="/login" replace />;
}
