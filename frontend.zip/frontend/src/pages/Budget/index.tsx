import { BudgetMechanic } from './BudgetMechanic';

export default function Budget() {
  // A definição do perfil deverá vir do usuário autenticado pela API.
  return <BudgetMechanic />;
}
