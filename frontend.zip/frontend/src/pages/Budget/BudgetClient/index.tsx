import './style.scss';

export function BudgetClient() {
  return <main className="dashboard"><h1>Orçamentos do cliente</h1><p>Esta área será exibida após a implementação da autenticação e da identificação do cliente conectado.</p></main>;
}
