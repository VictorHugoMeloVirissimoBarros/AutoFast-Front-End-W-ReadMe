import { useCallback, useEffect, useState } from 'react';
import { CiFilter } from 'react-icons/ci';
import { IoAddSharp } from 'react-icons/io5';
import { FaSortAmountDown } from 'react-icons/fa';
import './style.scss';
import { ModalCreateBudget } from '../../../components/ModalCreateBudget';
import { ModalBudget } from '../../../components/ModalBudget';
import { BudgetMechanicColumn } from '../../../components/BudgetMechanicColumn';
import { api, listarOrcamentos } from '../../../services/api';
import type { Orcamento } from '../../../services/api';

const columns = [
  { status: 'PENDENTE', title: 'Pendentes', accent: 'blue' as const },
  { status: 'EM_ANALISE', title: 'Em análise', accent: 'purple' as const },
  { status: 'APROVADO', title: 'Aprovados', accent: 'green' as const },
  { status: 'RECUSADO', title: 'Recusados', accent: 'gray' as const },
];

export function BudgetMechanic() {
  const [orcamentos, setOrcamentos] = useState<Orcamento[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [modalCriar, setModalCriar] = useState(false);
  const [orcamentoSelecionado, setOrcamentoSelecionado] = useState<Orcamento | null>(null);

  const carregarOrcamentos = useCallback(async () => {
    setCarregando(true); setErro('');
    try { const response = await listarOrcamentos(); setOrcamentos(response.data); }
    catch { setErro('Não foi possível carregar os orçamentos. Verifique se o Back-end está ativo.'); }
    finally { setCarregando(false); }
  }, []);

  useEffect(() => { void carregarOrcamentos(); }, [carregarOrcamentos]);

  const excluir = async (id: number) => {
    if (!window.confirm('Deseja realmente excluir este orçamento?')) return;
    try { await api.delete(`/orcamentos/${id}`); setOrcamentoSelecionado(null); await carregarOrcamentos(); }
    catch { setErro('Não foi possível excluir o orçamento.'); }
  };

  const atualizarDados = async (orcamento: Orcamento, dados: Partial<Orcamento>) => {
    try { await api.put(`/orcamentos/${orcamento.id}`, dados); setOrcamentoSelecionado(null); await carregarOrcamentos(); }
    catch { setErro('Não foi possível salvar as alterações do orçamento.'); }
  };

  const atualizarStatus = async (orcamento: Orcamento, status: Orcamento['status']) => {
    try { await api.put(`/orcamentos/${orcamento.id}`, { ...orcamento, status }); setOrcamentoSelecionado(null); await carregarOrcamentos(); }
    catch { setErro('Não foi possível atualizar o orçamento.'); }
  };

  const formatarValor = (valor?: number) => valor == null ? 'A definir' : valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const formatarData = (data?: string) => data ? new Date(data).toLocaleDateString('pt-BR') : '—';

  return <div className="dashboard-mechanic"><div className="dashboard-mechanic-shell">
    <header className="dashboard-mechanic-header"><div><h1 className="dashboard-mechanic-title">Orçamentos</h1><p className="dashboard-mechanic-subtitle">Acompanhe os orçamentos cadastrados na oficina</p></div>
      <div className="dashboard-mechanic-actions"><button type="button" className="dashboard-mechanic-action-button dashboard-mechanic-action-button--ghost" onClick={carregarOrcamentos}><CiFilter size={20}/> Atualizar</button><button type="button" className="dashboard-mechanic-action-button dashboard-mechanic-action-button--ghost" onClick={() => setOrcamentos([...orcamentos].sort((a,b) => b.id-a.id))}><FaSortAmountDown size={16}/> Recentes</button><button type="button" onClick={() => setModalCriar(true)} className="dashboard-mechanic-action-button dashboard-mechanic-action-button--primary"><IoAddSharp/> Novo orçamento</button></div>
    </header>
    {erro && <p role="alert" className="form-error">{erro}</p>}
    {modalCriar && <ModalCreateBudget toggleModal={() => setModalCriar(false)} onCreated={carregarOrcamentos}/>}
    {orcamentoSelecionado && <ModalBudget orcamento={orcamentoSelecionado} onClose={() => setOrcamentoSelecionado(null)} onDelete={() => excluir(orcamentoSelecionado.id)} onStatusChange={status => atualizarStatus(orcamentoSelecionado, status)} onUpdate={dados => atualizarDados(orcamentoSelecionado, dados)}/>}
    {carregando ? <p>Carregando orçamentos...</p> : <div className="dashboard-mechanic-board" role="list" aria-label="Quadro de orçamentos">{columns.map(column => {
      const cards = orcamentos.filter(o => o.status === column.status).map(o => ({ id: `#${o.id}`, title: o.peca?.descricaoProblema || 'Peça/serviço não informado', client: o.cliente?.nome || `Cliente #${o.cliente?.id ?? '—'}`, value: formatarValor(o.valorTotal), time: formatarData(o.dataSolicitacao), initials: '', tone: 'blue' as const, tag: o.status, onClick: () => setOrcamentoSelecionado(o) }));
      return <BudgetMechanicColumn key={column.status} column={{ title: column.title, count: cards.length, accent: column.accent, cards }} toggleModal={() => setModalCriar(true)} toggleModalBudget={() => undefined}/>;
    })}</div>}
    {!carregando && orcamentos.length === 0 && !erro && <p className="dashboard-mechanic-cards-alert">Nenhum orçamento cadastrado. Clique em “Novo orçamento” para começar.</p>}
  </div></div>;
}
