import { useState } from 'react';
import type { FormEvent } from 'react';
import './style.scss';
import { NavBar } from '../../components/NavBar';
import { Link, useNavigate } from 'react-router-dom';
import { entrarUsuario } from '../../services/api';

export default function Login() {
  const navigate = useNavigate();
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErro('');
    const form = new FormData(event.currentTarget);
    const dados = {
      email: String(form.get('email') || '').trim(),
      senha: String(form.get('senha') || ''),
    };

    try {
      setCarregando(true);
      const { data } = await entrarUsuario(dados);
      localStorage.setItem('autofast_token', data.token);
      localStorage.setItem('autofast_usuario', JSON.stringify({
        id: data.id, nome: data.nome, email: data.email, perfil: data.perfil,
      }));
      navigate('/orcamentos', { replace: true });
    } catch (error: any) {
      setErro(error?.response?.data?.detail || error?.response?.data?.message ||
        'E-mail ou senha inválidos. Confira os dados e tente novamente.');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <>
      <NavBar />
      <div className="page-bg" aria-hidden="true">
        <div className="grid-layer"></div>
        <div className="glow glow-1"></div>
        <div className="glow glow-2"></div>
      </div>
      <main className="auth-layout">
        <section className="form-panel" aria-label="Formulario de login">
          <div className="form-card">
            <div className="form-header">
              <p className="badge">Acesso seguro</p>
              <h2>Entrar na conta</h2>
              <p>Use seu e-mail e senha para continuar.</p>
            </div>
            <form className="auth-form" onSubmit={handleSubmit}>
              <label htmlFor="email">E-mail</label>
              <input id="email" name="email" type="email" placeholder="voce@oficina.com" required />
              <div className="field-row">
                <label htmlFor="senha">Senha</label>
                <span className="aux-link">Esqueci minha senha</span>
              </div>
              <input id="senha" name="senha" type="password" placeholder="Digite sua senha" required />
              {erro && <p role="alert" className="auth-error">{erro}</p>}
              <button type="submit" className="btn-submit" disabled={carregando}>
                {carregando ? 'Entrando...' : 'Entrar agora'}
              </button>
            </form>
            <p className="switch-auth">
              Ainda nao tem conta? <Link to="/cadastrar">Cadastre-se</Link>
            </p>
          </div>
        </section>
      </main>
    </>
  );
}
