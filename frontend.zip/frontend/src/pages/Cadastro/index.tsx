import { useState } from 'react';
import type { FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { NavBar } from '../../components/NavBar';
import { cadastrarUsuario } from '../../services/api';
import './style.scss';

export default function Register() {
  const navigate = useNavigate();
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErro('');
    const form = new FormData(event.currentTarget);
    const senha = String(form.get('senha') || '');
    const confirmarSenha = String(form.get('confirmar-senha') || '');

    if (senha.length < 8) {
      setErro('A senha precisa ter pelo menos 8 caracteres.');
      return;
    }
    if (senha !== confirmarSenha) {
      setErro('As senhas não coincidem.');
      return;
    }

    const dados = {
      nome: String(form.get('nome') || '').trim(),
      telefone: String(form.get('telefone') || '').trim(),
      email: String(form.get('email') || '').trim(),
      senha,
      perfil: String(form.get('perfil') || '') as 'cliente' | 'mecanico',
      cidade: String(form.get('cidade') || '').trim(),
    };

    try {
      setCarregando(true);
      const { data } = await cadastrarUsuario(dados);
      localStorage.setItem('autofast_token', data.token);
      localStorage.setItem('autofast_usuario', JSON.stringify({
        id: data.id, nome: data.nome, email: data.email, perfil: data.perfil,
      }));
      navigate('/orcamentos', { replace: true });
    } catch (error: any) {
      const mensagem = error?.response?.data?.detail || error?.response?.data?.message ||
        (error?.response?.status === 409 ? 'Este e-mail já está cadastrado.' : null) ||
        'Não foi possível realizar o cadastro. Confira se o backend está ligado e tente novamente.';
      setErro(mensagem);
    } finally {
      setCarregando(false);
    }
  }

  return (
    <>
      <NavBar />
      <div className="page-bg" aria-hidden="true">
        <div className="grid-layer"></div>
        <div className="glow glow-1"></div>
        <div className="glow glow-2"></div>
      </div>
      <main className="register-layout">
        <section className="form-panel" aria-label="Formulario de cadastro">
          <div className="form-card">
            <div className="form-header">
              <p className="badge">Comece gratis</p>
              <h1>Criar conta no AutoFast</h1>
              <p>Preencha seus dados para centralizar os orcamentos da sua oficina.</p>
            </div>
            <form className="register-form" onSubmit={handleSubmit}>
              <div className="grid-two">
                <div className="field">
                  <label htmlFor="nome">Nome completo</label>
                  <input id="nome" name="nome" type="text" placeholder="Ex: Joao Pereira" required />
                </div>
                <div className="field">
                  <label htmlFor="telefone">Telefone</label>
                  <input id="telefone" name="telefone" type="tel" placeholder="(11) 99999-9999" required />
                </div>
              </div>
              <div className="field">
                <label htmlFor="email">E-mail</label>
                <input id="email" name="email" type="email" placeholder="voce@autofast.com" required />
              </div>
              <div className="grid-two">
                <div className="field">
                  <label htmlFor="perfil">Perfil</label>
                  <select id="perfil" name="perfil" defaultValue="" required>
                    <option value="" disabled>Selecione seu perfil</option>
                    <option value="mecanico">Mecanico</option>
                    <option value="cliente">Cliente</option>
                  </select>
                </div>
                <div className="field">
                  <label htmlFor="cidade">Cidade</label>
                  <input id="cidade" name="cidade" type="text" placeholder="Sao Paulo" required />
                </div>
              </div>
              <div className="grid-two">
                <div className="field">
                  <label htmlFor="senha">Senha</label>
                  <input id="senha" name="senha" type="password" placeholder="Minimo de 8 caracteres" minLength={8} required />
                </div>
                <div className="field">
                  <label htmlFor="confirmar-senha">Confirmar senha</label>
                  <input id="confirmar-senha" name="confirmar-senha" type="password" placeholder="Repita sua senha" required />
                </div>
              </div>
              <label className="check-field" htmlFor="termos">
                <input id="termos" type="checkbox" required />
                <span>Aceito os termos de uso e a politica de privacidade.</span>
              </label>
              {erro && <p role="alert" className="auth-error">{erro}</p>}
              <button type="submit" className="btn-submit" disabled={carregando}>
                {carregando ? 'Criando conta...' : 'Criar minha conta'}
              </button>
            </form>
            <p className="switch-auth">
              Ja possui uma conta? <Link to="/login">Entrar agora</Link>
            </p>
          </div>
        </section>
      </main>
    </>
  );
}
