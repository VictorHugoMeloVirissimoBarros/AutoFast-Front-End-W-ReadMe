import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaBuilding, FaRegUser } from 'react-icons/fa';
import { CiLock } from 'react-icons/ci';
import { atualizarMeuNome, excluirMinhaConta } from '../../services/api';
import './style.scss';

interface UsuarioSalvo {
  id: number;
  nome: string;
  email: string;
  perfil: string;
}

export default function Profile() {
  const navigate = useNavigate();
  const [erro, setErro] = useState('');
  const [excluindo, setExcluindo] = useState(false);
  const [editandoNome, setEditandoNome] = useState(false);
  const [novoNome, setNovoNome] = useState('');
  const [salvandoNome, setSalvandoNome] = useState(false);
  const [usuario, setUsuario] = useState<UsuarioSalvo | null>(() => {
    try {
      const valor = localStorage.getItem('autofast_usuario');
      return valor ? JSON.parse(valor) as UsuarioSalvo : null;
    } catch {
      return null;
    }
  });

  function sairDoPerfil() {
    localStorage.removeItem('autofast_token');
    localStorage.removeItem('autofast_usuario');
    navigate('/login', { replace: true });
  }

  async function handleSalvarNome() {
    const nome = novoNome.trim();
    if (!nome) { setErro('Informe um nome válido.'); return; }
    setErro('');
    setSalvandoNome(true);
    try {
      const { data } = await atualizarMeuNome(nome);
      const atualizado = { ...(usuario as UsuarioSalvo), nome: data.nome };
      localStorage.setItem('autofast_usuario', JSON.stringify(atualizado));
      setUsuario(atualizado);
      setEditandoNome(false);
    } catch (error: any) {
      setErro(error?.response?.data?.detail || error?.response?.data?.message || 'Não foi possível atualizar o nome. Tente novamente.');
    } finally { setSalvandoNome(false); }
  }

  async function handleExcluirConta() {
    const confirmado = window.confirm(
      'Tem certeza de que deseja excluir sua conta? Esta ação também removerá os orçamentos e veículos vinculados e não poderá ser desfeita.'
    );
    if (!confirmado) return;

    setErro('');
    setExcluindo(true);
    try {
      await excluirMinhaConta();
      localStorage.removeItem('autofast_token');
      localStorage.removeItem('autofast_usuario');
      navigate('/login', { replace: true });
    } catch (error: any) {
      setErro(error?.response?.data?.detail || error?.response?.data?.message ||
        'Não foi possível excluir a conta. Tente novamente.');
    } finally {
      setExcluindo(false);
    }
  }

  return <div className="profile">
    <h1>Meu perfil</h1>
    <div className="profile-container">
      <aside className="profile-aside">
        <div className="profile-aside-user">
          <div className="profile-aside-user-info">
            <h3>{usuario?.nome || 'Usuário'}</h3>
            <p>{usuario?.email || 'E-mail não disponível'}</p>
          </div>
        </div>
        <nav className="profile-aside-nav">
          <ul>
            <li><a className="active" href="#personal-data"><FaRegUser size={14}/> Dados pessoais</a></li>
            <li><a href="#company-data"><FaBuilding size={14}/> Dados da oficina</a></li>
            <li><a href="#password"><CiLock size={14}/> Senha</a></li>
          </ul>
        </nav>
        <div className="profile-aside-logout">
          <button type="button" onClick={sairDoPerfil}>Sair do perfil</button>
          <button type="button" className="profile-delete-button" onClick={handleExcluirConta} disabled={excluindo}>
            {excluindo ? 'Excluindo...' : 'Excluir conta'}
          </button>
        </div>
      </aside>

      <section className="profile-content">
        <div className="profile-content-form" id="personal-data">
          <div className="profile-content-form-header">
            <div className="profile-content-form-header-title"><FaRegUser size={18}/><h3>Dados pessoais</h3></div>
          </div>
          <div className="profile-content-form-group profile-name-row"><label>Nome</label>{!editandoNome ? <><span>{usuario?.nome || '—'}</span><button type="button" className="profile-edit-name" onClick={() => { setNovoNome(usuario?.nome || ''); setEditandoNome(true); setErro(''); }}>Editar</button></> : <div className="profile-name-editor"><input aria-label="Novo nome" value={novoNome} onChange={e => setNovoNome(e.target.value)} maxLength={120} /><button type="button" onClick={handleSalvarNome} disabled={salvandoNome}>{salvandoNome ? 'Salvando...' : 'Salvar'}</button><button type="button" onClick={() => setEditandoNome(false)} disabled={salvandoNome}>Cancelar</button></div>}</div>
          <div className="profile-content-form-group"><label>E-mail</label><span>{usuario?.email || '—'}</span></div>
          <div className="profile-content-form-group"><label>Perfil</label><span>{usuario?.perfil || '—'}</span></div>
        </div>
        <div className="profile-content-form" id="company-data">
          <div className="profile-content-form-header">
            <div className="profile-content-form-header-title"><FaBuilding size={18}/><h3>Dados da oficina</h3></div>
          </div>
          <p>Os dados da oficina ainda não estão vinculados a um cadastro específico.</p>
        </div>
        <div className="profile-content-form" id="password">
          <div className="profile-content-form-header">
            <div className="profile-content-form-header-title"><CiLock size={18}/><h3>Senha</h3></div>
          </div>
          <p>Para alterar a senha, será necessário implementar o fluxo de alteração de senha.</p>
        </div>
        {erro && <p role="alert" className="profile-error">{erro}</p>}
      </section>
    </div>
  </div>;
}
