import './style.scss';
import { Chat } from '../../components/Chat';

export default function ChatPage() {
  return <main className="chat-page"><h1>Mensagens</h1><p>As conversas serão exibidas quando estiverem vinculadas a um orçamento.</p><Chat /></main>;
}
