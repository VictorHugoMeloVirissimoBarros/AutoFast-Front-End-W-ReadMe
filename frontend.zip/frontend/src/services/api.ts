import axios from 'axios';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080/api',
  headers: { 'Content-Type': 'application/json' },
});

// Anexa o JWT automaticamente nas chamadas às rotas protegidas.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('autofast_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export interface AuthResponse {
  token: string;
  id: number;
  nome: string;
  email: string;
  perfil: string;
}

export interface CadastroDados {
  nome: string;
  telefone: string;
  email: string;
  senha: string;
  perfil: 'cliente' | 'mecanico';
  cidade: string;
}

export interface LoginDados {
  email: string;
  senha: string;
}

export const cadastrarUsuario = (dados: CadastroDados) =>
  api.post<AuthResponse>('/auth/cadastro', dados);

export const excluirMinhaConta = () => api.delete('/auth/conta');
export const atualizarMeuNome = (nome: string) =>
  api.patch<{ nome: string }>('/auth/nome', { nome });

export const entrarUsuario = (dados: LoginDados) =>
  api.post<AuthResponse>('/auth/login', dados);

export interface Cliente { id: number; nome: string; telefone?: string; email?: string }
export interface Veiculo { id: number; marca: string; modelo: string; ano: number; cliente?: { id: number } }
export interface Orcamento {
  id: number;
  dataSolicitacao?: string;
  status: 'PENDENTE' | 'EM_ANALISE' | 'APROVADO' | 'RECUSADO';
  valorPecas?: number;
  valorMaoDeObra?: number;
  valorTotal?: number;
  prazoEntrega?: number;
  cliente?: Cliente;
  veiculo?: Veiculo;
  peca?: { id: number; descricaoProblema: string; fotoUrl?: string };
}

export const listarOrcamentos = () => api.get<Orcamento[]>('/orcamentos');
export const listarClientes = () => api.get<Cliente[]>('/clientes');
export const listarVeiculos = () => api.get<Veiculo[]>('/veiculos');
export const listarVeiculosPorCliente = (clienteId: number) =>
  api.get<Veiculo[]>(`/veiculos/cliente/${clienteId}`);
export const criarClienteParaOrcamento = (dados: {
  nome: string;
  telefone: string;
  email: string;
}) => api.post<Cliente>('/clientes/rapido', dados);
export const criarVeiculo = (dados: {
  marca: string;
  modelo: string;
  ano: number;
  cliente: { id: number };
}) => api.post<Veiculo>('/veiculos', dados);
export const criarPeca = (dados: { descricaoProblema: string; fotoUrl: string }) => api.post('/pecas', dados);
export const criarOrcamento = (dados: unknown) => api.post<Orcamento>('/orcamentos', dados);
export const atualizarOrcamento = (id: number, dados: Partial<Orcamento>) => api.put<Orcamento>(`/orcamentos/${id}`, dados);
export const excluirOrcamento = (id: number) => api.delete(`/orcamentos/${id}`);
